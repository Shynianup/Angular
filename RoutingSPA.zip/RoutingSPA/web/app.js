var productApp = angular.module('productApp',['productControllers','ngRoute']);

productApp.config(['$routeProvider',function($routeProvider){
  $routeProvider.
          when('/main',{
              templateUrl : 'Login',
              controller:'LoginCtrl'
          }).
          when('/login',{
              templateUrl : 'Home',              
          }).  
         when('/viewproductlist',{
              templateUrl : 'partials/product-list.html',
              controller:'ProductListCtrl'
          }).
        when('/product/:name',{
              templateUrl : 'partials/product-detail.html',
              controller:'ProductDetailCtrl'
          }).
                  otherwise({
                      redirectTo: '/main'
                  });
         
        
}]);

