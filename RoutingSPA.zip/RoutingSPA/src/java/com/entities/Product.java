package com.entities;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
*
* @author
*/
public class Product {

    private long product_id;
    private String product_code;
    private String description;    
    private List products;
    private String prod_code;

    public Product() {
        try {
            dbConnect();
        } catch (Exception e) {
            System.out.println("Exception " + e.getMessage());
        }
    }

    public Product(long product_id, String product_code, String description) {
        this.product_id = product_id;
        this.product_code = product_code;
        this.description = description;
    }
    public String getProd_code() {
        return prod_code;
    }

    public void setProd_code(String prod_code) {
        this.prod_code = prod_code;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProduct_code() {
        return product_code;
    }

    public void setProduct_code(String product_code) {
        this.product_code = product_code;
    }

    public long getProduct_id() {
        return product_id;
    }

    public void setProduct_id(long product_id) {
        this.product_id = product_id;
    }

    public List getProducts() {
        return products;
    }

    public void setProducts(List products) {
        this.products = products;
    }

    private void dbConnect() throws SQLException, ClassNotFoundException {
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/sample", "app", "app");
        System.out.println(prod_code);
        String myquery = "SELECT PRODUCT_ID, PRODUCT_CODE, DESCRIPTION from APP.PRODUCT ";
        
        Statement statement = connection.createStatement();
        ResultSet results = statement.executeQuery(myquery);
        setProducts(new ArrayList());
        while (results.next()) {
            getProducts().add(new Product(results.getLong("PRODUCT_ID"), 
                    results.getString("PRODUCT_CODE"), 
                    results.getString("DESCRIPTION")));
        }
    }
}
