//declare main module and its dependencies

//declare config block for main module to provide route configurations
/*
 * Route1: "/main"
 *      Display Login template. Use the same LoginCtrl here.
 * 
 * Route2: "/home/student"
 *      Display the partial page ViewBooks_Student.html present in the partials folder. 
 *      Use the same BookListCtrl_Student here.
 *      
 * Route3: "/home/librarian"
 *      Display the partial page ViewBooks_Librarian.html present in the partials folder. 
 *      Use the same BookListCtrl_Librarian here.
 *      
 *      
 * Route4: "/issue/:bookId"
 *      Display the partial page IssueBook.html present in the partials folder. 
 *      Use the IssueBookCtrl here.   
 *      
 *  Route5: "/return/:bookId"
 *      Display the partial page ReturnBook.html present in the partials folder. 
 *      Use the ReturnBookCtrl here. 
 *      
 *  Route6: "/AddBook"
 *      Display the partial page AddBook.html present in the partials folder. 
 *      Use the AddBookCtrl here. 
 *                        
 * Default Route: "/main"
 */