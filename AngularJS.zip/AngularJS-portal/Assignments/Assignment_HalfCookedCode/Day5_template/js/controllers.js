//declare controller module

/*
 * declare LoginCtrl 
 * Code description for LoginCtrl:
        Method1:
            validate(user): 
            a. Need to validate entered username and password and alert appropriate messages
            b. cross verify against the roles inside roles.json file
             and associate the username to rootScope, if valid
            c. if username is set to rootScope , then display success message. 
                otherwise display error message.
                
            [ Hint: Use angular.forEach for iterations]

            Redirect user to "/home/student" if role is student.
            Redirect user to "/home/librarian" if role is librarian.
            Redirect user to default route if invalid login data is given.

            
 */

/*
 * rename BookListCtrl  to BookListCtrl_Student
 * Code description for BookListCtrl_Student:
        To Retrieve book details from books.json , invoke the custom service.

        Method1: changeView:
            Define the changeView function which will invoke the custom service
        to set the books model in the rootScope.
 */


/*
 * declare BookListCtrl_Librarian
 * Code description for BookListCtrl_Librarian:
        Modify as below:
        1. if books inside rootScope is undefined, then invoke custom service to 
        set the books model in the rootScope.
        2. declare a method 'issue' which will accept a bookId.
            update the url to '/issue/<bookId>'
        3. declare a method 'return' which will accept a bookId.
            update the url to '/return/<bookId>'
 */

/*
 * declare IssueBookCtrl
 * Code description for IssueBookCtrl:
        
        1. retrieve the bookId from the routeParameter
        2. retrieve the corresponding book information from the books json array 
        and store in a book model inside current scope.
        3. declare a method 'issue' which will accept a bookId.
                a. inside this method, retrieve the corresponding book and update the issued to true for the book.
                b. redirect the user to '/home/librarian'.
 */

/*
 * declare ReturnBookCtrl
 * Code description for ReturnBookCtrl:
        
        1. retrieve the bookId from the routeParameter
        2. retrieve the corresponding book information from the books json array 
        and store in a book model inside current scope.
        3. declare a method 'return' which will accept a bookId.
                a. inside this method, retrieve the corresponding book and update the issued to false for the book.
                b. redirect the user to '/home/librarian'.
 */

/*
 * declare AddBookCtrl
 * Code description for AddBookCtrl:
        
        1.declare a method 'addBook' which will accept a book.
        2.inside this method:
                a. set imgUrl  to "imgs/DefaultBookImage.jpg" and issued to false,
                    for the book received.
                b. Add this book to books model inside rootScope.                 
                c. redirect the user to '/home/librarian'.
 */

 
