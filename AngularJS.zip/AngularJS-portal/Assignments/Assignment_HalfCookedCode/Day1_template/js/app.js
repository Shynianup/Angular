//declare main module and its dependencies

