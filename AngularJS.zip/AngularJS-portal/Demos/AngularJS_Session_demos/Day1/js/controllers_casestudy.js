function ItemCtrl($scope) {

$scope.items = [
    {text:'Wheat Flour', done:true},
    {text:'Toothpaste', done:false},
 {text:'Talcum Powder', done:false},
  {text:'Cooking Oil', done:false},
    {text:'Pooja Items', done:false},
    {text:'Mobile Items', done:false}
];

 
 $scope.remaining = function() {
    
    var count = 0;

   	 angular.forEach($scope.items, function(item) {
   	if(item.done==false)
		count=count+1;
    	});

   return count;
  };  

$scope.addItem = function() {
     // $scope.items=[];
    $scope.items.push({text:$scope.itemText, done:false});
   $scope.itemText = '';    
    };

}
