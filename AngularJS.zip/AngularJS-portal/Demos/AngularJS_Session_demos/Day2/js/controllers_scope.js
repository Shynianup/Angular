function ItemCtrl1($scope,$rootScope) {

$scope.title="Please check the items as and when you finish buying";

 $scope.items = [
    {text:'Wheat Flour', done:true},
    {text:'Toothpaste', done:false}];

 
 $scope.remaining = function(items) {
	
    var count = 0;

   	 angular.forEach(items, function(item) {
   	if(item.done==false)
		count=count+1;
    	});

   return count;
   
  };  
$rootScope.username="hi";

}

function ItemCtrl2($scope,$rootScope) {

//$scope.title="List2:Please check the items as and when you finish buying";
//
console.log($rootScope.username)
 $scope.items = [
    {text:'Pen', done:true},
    {text:'Pencil', done:false},
	{text:'Book', done:false},
	{text:'Crayon', done:false}
]; 

}

