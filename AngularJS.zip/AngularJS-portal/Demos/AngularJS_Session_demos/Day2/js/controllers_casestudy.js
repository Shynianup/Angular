function ItemCtrl1($scope) {

 $scope.items = [
    {text:'Wheat Flour', done:true},
    {text:'Toothpaste', done:false}];

 
 $scope.remaining = function() {
    var count = 0;

   	 angular.forEach($scope.items, function(item) {
   	if(item.done==false)
		count=count+1;
    	});

   return count;
  };  


}

function ItemCtrl2($scope) {

 $scope.items = [
    {text:'Pen', done:true},
    {text:'Pencil', done:false},
	{text:'Book', done:false},
	{text:'Crayon', done:false}

];

 
 $scope.remaining = function() {
    var count = 0;

   	 angular.forEach($scope.items, function(item) {
   	if(item.done==false)
		count=count+1;
    	});

   return count;
  };  


}

