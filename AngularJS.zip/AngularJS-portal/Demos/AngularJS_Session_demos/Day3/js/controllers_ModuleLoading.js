var app=angular.module('app',[]);

app.config(function($provide){
    $provide.value("timeConfig", new Date());
    $provide.value("timeRun", new Date());
    for(var x=0;x<500000000;x++)
    {
     var y=Math.sqrt(Math.log(x));   
    }
});

app.run(function(timeConfig, timeRun){
    timeRun.setTime(new Date().getTime());
    
});

app.controller('Ctrl',['$scope','timeConfig','timeRun', 
    function($scope, timeConfig, timeRun) {
      $scope.timeConfig=timeConfig;
      $scope.timeRun=timeRun;
    }    
])