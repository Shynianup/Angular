var bagControllers = angular.module('bagControllers', []);
 
//custom service
bagControllers.factory('Data', ['$http', function(http){
	return {
		getData: function() {
		console.log('inside custom service');
		return http.get('data/bags.json').then(function(result) {
			return result.data;
		}
		);
	}
	};
	
}
]);

 bagControllers.controller('LoginCtrl', ['$scope',  '$location', '$rootScope',
  function ($scope, $location, $rootScope) {
   
      $scope.validate=function()
      {         
          if($scope.username===$scope.password)
          {
              $rootScope.username=$scope.username;
              $location.path( "/login" );
         }
         else
         {
             alert("Please enter valid data");
             $location.path( "/main" );
         }
      }
   
  }]);
bagControllers.controller('BagListCtrl', ['$scope', '$http', 'Data',
  function ($scope, $http, Data) {
  
    //$http.get('data/bags.json').success(function(data) {
      $scope.bags = Data.getData();
    //});

    $scope.orderProp = 'age';
  }]);
 
bagControllers.controller('BagDetailCtrl', ['$scope', '$routeParams', 'Data',
  function($scope, $routeParams, Data) {
    $scope.bagId = $routeParams.code;
    var f=Data.getData();
    console.log(f);
  }]);