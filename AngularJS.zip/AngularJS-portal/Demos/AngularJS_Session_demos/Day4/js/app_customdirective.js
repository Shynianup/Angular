var bagApp = angular.module('bagApp', [
    'bagControllers'
    ]);
 
bagApp.config(['$routeProvider',
    function($routeProvider) {
        $routeProvider.
        when('/main', {
            templateUrl: 'Login',
            controller: 'LoginCtrl'
        }).
        when('/login', {
            templateUrl: 'Home'
        }).
         when('/viewbaglist', {
            templateUrl: 'partials/bag-list.html',
            controller: 'BagListCtrl'
        }).        
        when('/bags/:code', {
            templateUrl: 'partials/bag-detail.html',
            controller: 'BagDetailCtrl'
        }).
        otherwise({
            redirectTo: '/main'
        });
    }]);



//first eg: custom directive with restriction 'E'
/*bagApp.directive('headerline',function(){
    return {
        restrict : 'E',
        scope    : {
          'title'  : '=title'
         
        },
        template : '<header>'+
                      '<h2> <i>{{ title }} </i></h2>'+
                    '</header>'     
      }
    });
*/

//second eg:custom directive with restriction 'EA'

bagApp.directive('headerline',function(){
    return {
        restrict : 'EA',
        scope    : {
          'title'  : '=title'
         
        },
        template : '<header>'+
                      '<h2> {{ title }} </h2>'+
                    '</header>'     
      ,
      link: function($scope,element,attrs){
    		element.bind("mouseenter", function() {
    			element.css("font-style", "italic");
    			
    			});    			
      }
    }});


//third eg:custom directive with restriction 'M'
bagApp.directive('mycommentdir', function() {
	return  {
restrict:"M",
link: function(){

		console.log("Using directive as comment. Code to include dynamic view");
}

		};
});

//fourth eg:custom directive with restriction 'C'
/*bagApp.directive('myclassdir', function() {
	return  {
restrict:"C",
link: function($scope,element){

		element.bind("mouseenter", function() {
			element.css("border-radius", "10px");
			});  
		
}

		};
});*/


//fifth eg: custom directive for binding events on a button
/*bagApp.directive("buttonclick", function() {
	return  {
		restrict: 'A',
		link: function(s,e) {
			e.bind("click", function(){
				console.log('click event triggered');
			}	
			);
		}
	}
	});
*/
//custom filter which will reverse the string passed to it
bagApp.filter("reverseString", function() {
	return function(message) {
		return message.split("").reverse().join("");
	}
	
	});

