var bagControllers = angular.module('bagControllers', []);

bagControllers.controller('LoginCtrl', ['$scope',  '$location', '$rootScope',
 function ($scope, $location, $rootScope) {
$scope.validate=function()
      {         
          if($scope.username===$scope.password)
          { $rootScope.username=$scope.username;
              $location.path( "/login" );
         }
         else
         {alert("enter valid data");
             $location.path( "/main" );
          }      
} }]);
bagControllers.controller('BagListCtrl', ['$scope', '$http',
  function ($scope, $http) {  
    $http.get('data/bags.json').success(function(data) {
      $scope.bags = data;
    }); 
    $scope.orderProp = 'age';
  }]);
 
bagControllers.controller('BagDetailCtrl', ['$scope', '$routeParams',
  function($scope, $routeParams) {
    $scope.bagId = $routeParams.xyz;
  }]);
