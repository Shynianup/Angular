var app=angular.module('module1',[]);

app.controller('ContactCtrl', function($scope){
	
	$scope.contacts = null;
	$scope.contacts= [
	{name: 'Payal', number:1234, status:true},
	{name: 'Jugs', number:1234, status:false},
	{name: 'Abhi', number:1234, status:false},
	{name: 'Reshmi', number:1234, status:false},	
	
	];	
	


$scope.numberOfInActiveContacts = function(){
	
	var count =0;
	angular.forEach($scope.contacts,function(contact){
		if(contact.status==false){
			count=count+1;
		}		
	});
	return count;
};


$scope.addContact = function(){
	
	$scope.contacts.push({name:$scope.name,number:$scope.number,status:false})
	$scope.name="";
};

})