var productControllers=angular.module('productControllers',[]);

productControllers.controller('LoginCtrl',
['$scope','$location','$rootScope',
    function($scope,$location,$rootScope){
        $scope.validate=function(){
            if($scope.username==$scope.password)
            {
                $rootScope.username=$scope.username;
                $location.path("/login");
            }
            else
            {
                alert("enter valid data");
                $location.path("/main");
            }
        };
    }]);

productControllers.controller('ProductListCtrl',
function($rootScope,$http){
    $http.get('getproducts.jsp').success(function(data){
        $rootScope.products=data;
    }).error(function(data, status){alert(data+ " "+status);});
});

productControllers.controller('ProductDetailCtrl',
['$scope','$rootScope','$routeParams',
    function($scope,$rootScope,$routeParams){
        productSelected=$routeParams.name;
        angular.forEach($rootScope.products,function(productt){
            if(productSelected==productt.name)
            {
                $rootScope.productName=productt.name;
                $rootScope.code=productt.code;
            }
        });
    }
]);
