var app2=angular.module('module2',[]);

app2.controller('ctrl2',function($scope){
	
	$scope.name="Anup";
	$scope.age=28;
	
})