var app=angular.module('module1',['module2']);

app.controller('ctrl1',function($scope){
	
	$scope.name="Shyni";
	$scope.age=23;
	$scope.display = function(){
		
		console.log("Hello world");
	}	
})