//declare main module and its dependencies
var app = angular.module('app',['controller1']);

app.controller($scope,function(){
    
      $scope.footer="Copyright @ Infosys Limited";
    
})

