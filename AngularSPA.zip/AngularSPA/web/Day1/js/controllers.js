//declare controller module
var app1 = angular.module('controller1',[]);

/*
 * declare LoginCtrl 
 * Code description for LoginCtrl:
        Method1:
            validate(user): validates entered username and password and alerts appropriate messages
 */
app1.controller('loginCtrl', function($scope){
    
    $scope.users = [
        
       {name: 'Payal', password : 'Payal'},
	{name: 'Jugs', password: 'Jugs'},
	{name: 'Abhi', password: 'Abhi'}
        
    ]
	
	
$scope.validateUser = function(u){
    var flag = false;
	angular.forEach($scope.users,function(user){
            if(user.name == u.name)
               flag = true; 
        });
        
        if(flag==true){
            alert("Login Successful");
        }else{
            alert("Please enter valid credentials");
        }
};	
	
})


 
 /*
 * declare BookListCtrl 
 * Code description for BookListCtrl:
        Hard code book details in json array and store this in a books model
 */
 app1.controller('bookListCtrl', function($scope){
	
	$scope.books =[
            {
                "bookId":101,
                "bookTitle": "AngularJs",
                "topic": "AngularJs",
                "author":"Green",
                "cost":375,
                "imgUrl":"imgs/AngularJS1.JPG",
                "Issued":true
            },
            {
                "bookId":102,
                "bookTitle": "Instant AngularJs starter",
                "topic": "AngularJs",
                "author":"Dan Menard",
                "cost":4657,
                "imgUrl":"imgs/AngularJS2.JPG",
                "Issued":true
            },
            {
                "bookId":103,
                "bookTitle": "Ng-Book: the complete book on AngularJs",
                "topic": "AngularJs",
                "author":"Ari Lerner",
                "cost":4657,
                "imgUrl":"imgs/AngularJS3.JPG",
                "Issued":false
            },
            {
                "bookId":104,
                "bookTitle": "Developing backboneJS application",
                "topic": "BackboneJS",
                "author":"Green",
                "cost":650,
                "imgUrl":"imgs/BackboneJS1.JPG",
                "Issued":true
            },
            {
                "bookId":105,
                "bookTitle": "Backbone.js Patterns and Best Practises",
                "topic": "BackboneJS",
                "author":"Green",
                "cost":390,
                "imgUrl":"imgs/BackboneJS2.JPG",
                "Issued":true
            }
            
        ]
	
})






 
