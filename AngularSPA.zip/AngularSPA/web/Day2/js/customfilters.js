var libFilters = angular.module('libFilters',[]);

libFilters.filter('filterunissued', function(){
    
    return function(books,viewbookoption){
        if(viewbookoption!=undefined && viewbookoption!=""){
            var filtered= [];
            angular.forEach(book, function(book){
        if(book.issed==false){
            filtered.push(book);
        }
    });
    return filtered;
        }
        return books;
    };
});
