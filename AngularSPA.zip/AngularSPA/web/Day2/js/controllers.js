//declare controller module
var app1 = angular.module('controller1',[]);

/*
 * declare LoginCtrl 
 * Code description for LoginCtrl:
        Method1:
            validate(user): validates entered username and password and alerts appropriate messages
 */
app1.controller('loginCtrl', ['$scope','$location','$rootScope','$http',
function($scope,$location,$rootScope,$http){
    
   $http.get("Roles.json").success(function(data){
         $scope.users= data;
         alert($scope.users);
     }).error(function(data,status){
         alert(data+ " "+status);
     });
	
	
$scope.validateUser = function(u){
    var flag = false;
    var currUser = "";
	angular.forEach($scope.users,function(user){
            if(user.name == u.name){
               flag = true; 
           currUser = user;
       }
        });        
        
        if(flag==true){
            alert("Login Successful");
            if(currUser.Role === "student"){
                $rootScope.user=$scope.user;
                $location.path("/home/student"); 
            }else{
                $rootScope.user=$scope.user;
                $location.path("/home/librarian");  
            }
                         
        }else{
            alert("Please enter valid credentials");
        }
};	
	
}])



 
 /*
 * declare BookListCtrl 
 * Code description for BookListCtrl:
        Hard code book details in json array and store this in a books model
 */
 app1.controller('bookListCtrl_student', function(&scope,$rootScope,$http){
     
      $rootScope.pageTitle="View Books";
	
	$http.get("Books.json").success(function(data){
         $rootScope.books= data;
     }).error(function(data,status){
         alert(data+ " "+status);
     });
     
     $scope.change = function()
	
});


 app1.controller('bookListCtrl_librarian', function($rootScope,$http){
     $http.get("Books.json").success(function(data){
         $rootScope.books= data;
     }).error(function(data,status){
         alert(data+ " "+status);
     });

 });





 
