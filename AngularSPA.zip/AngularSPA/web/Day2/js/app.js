//declare main module and its dependencies
var app = angular.module('app',['controller1','ngRoute','libFilters']);


      
      
      app.config(['$routeProvider',function($routeProvider){
  $routeProvider.
          when('/main',{
              templateUrl : 'Login',
              controller:'loginCtrl'
          }).
          when('/home/librarian',{
              templateUrl : 'ViewBooks_Librarian.html',
              controller:'bookListCtrl_librarian'
          }).  
         when('/home/student',{
              templateUrl : 'ViewBooks_Student.html',
              controller:'bookListCtrl_student'
          }).  
          when('/issue/:bookId',{
              templateUrl : 'ViewBooks_Student.html',
              controller:'issueBookCtrl'
          }).
          when('/return/:bookId',{
              templateUrl : 'ViewBooks_Student.html',
              controller:'returnBookCtrl'
          }).
           otherwise({
                      redirectTo: '/main'
                  });
         
        
}]);
      
app.controller('ctrl',function($scope){
    
      $scope.footer="Copyright @ Infosys Limited";    
})
